ONLINE SHOPPING - DJANGO CONVERSION
===================================

This project ports the supplied PHP/HTML shopping site into a Django starter project.
It keeps the supplied product photos, Bootstrap 5 files, and the general grey background / product-card layout.

WINDOWS + SUBLIME TEXT SETUP
1. Install Python 3.10 or newer.
2. Extract this ZIP file. Open the extracted Onlineshopping_Django folder in Sublime Text.
3. Open Command Prompt and change directory to this folder (the folder containing manage.py).
4. Create a virtual environment:
   python -m venv .venv
5. Activate it:
   .venv\Scripts\activate
6. Install Django:
   python -m pip install -r requirements.txt
7. Create database tables:
   python manage.py makemigrations store
   python manage.py migrate
8. Start the website:
   python manage.py runserver
9. Open http://127.0.0.1:8000/ in your browser.

OPTIONAL ADMIN
Create an administrator with: python manage.py createsuperuser
Then visit http://127.0.0.1:8000/admin/ to manage products and orders.

PAGES
Home: /
Products: /products/
Search: /search/?query=tv
Login: /login/
Register: /register/
Cart: /cart/
Rewards: /rewards/
Profile / order history: /profile/ (login required)

IMPORTANT NOTES
- Product prices for Mobile phone (Rs 60,000), TV (Rs 10,000), and Washing Machine (Rs 22,000) came from the supplied home page. The supplied files did not specify prices for Bag, Shoes, or Fridge, so their prices are left at Rs 0.00 until you edit them in Django admin.
- The original PHP database connection only attempted a bare MySQL connection and did not define a database name or credentials. This conversion uses Django's SQLite database by default, so no MySQL setup is needed to run locally.
- Checkout creates a local demo order only. It does not collect payment or connect to a payment gateway, shipping provider, or live inventory service.
- The uploaded source contained HTML pages and a small PHP database test; there was no complete PHP cart/order backend to translate. The cart, account, and order features here are implemented as Django equivalents.
- Before deploying publicly, set a secure SECRET_KEY, DEBUG=False, configure ALLOWED_HOSTS, use a production database, HTTPS, and production static-file hosting.
