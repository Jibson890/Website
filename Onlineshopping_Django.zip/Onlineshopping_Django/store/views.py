from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from django.utils.http import url_has_allowed_host_and_scheme
from .models import Product, Order, OrderItem

DEFAULT_PRODUCTS = [
    ("Mobile phone", "60000.00", "Mobile phone.jpg", "Mobile phone"),
    ("TV", "10000.00", "img_TV.jpg", "Television"),
    ("Washing Machine", "22000.00", "Washing machine.jpg", "Washing machine"),
    ("School Bag", "0.00", "School Bag.jpg", "School bag"),
    ("Shoes", "0.00", "shoes.jpg", "Shoes"),
    ("Fridge", "0.00", "Fridge.jpg", "Refrigerator"),
]

def ensure_products():
    if not Product.objects.exists():
        for name, price, image, desc in DEFAULT_PRODUCTS:
            Product.objects.create(name=name, price=Decimal(price), image=image, description=desc)

def home(request):
    ensure_products()
    items = Product.objects.filter(active=True)[:3]
    return render(request, "store/home.html", {"products": items})

def products(request):
    ensure_products()
    return render(request, "store/products.html", {"products": Product.objects.filter(active=True)})

def search(request):
    ensure_products()
    query = request.GET.get("query", "").strip()
    results = Product.objects.filter(active=True, name__icontains=query) if query else Product.objects.none()
    return render(request, "store/search_results.html", {"query": query, "products": results})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "You are now logged in.")
            next_url = request.GET.get("next", "")
            if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
                return redirect(next_url)
            return redirect("home")
        messages.error(request, "Username or password is incorrect.")
    return render(request, "store/login.html")

def register(request):
    form = UserCreationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Your account has been created.")
        return redirect("home")
    return render(request, "store/register.html", {"form": form})

@require_POST
def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("home")

def _cart_items(request):
    ensure_products()
    cart_data = request.session.get("cart", {})
    products_by_id = {str(p.id): p for p in Product.objects.filter(id__in=[int(k) for k in cart_data if str(k).isdigit()])}
    rows, total = [], Decimal("0.00")
    for product_id, quantity in cart_data.items():
        product = products_by_id.get(str(product_id))
        if not product: continue
        quantity = max(1, int(quantity))
        line_total = product.price * quantity
        rows.append({"product": product, "quantity": quantity, "line_total": line_total})
        total += line_total
    return rows, total

def cart(request):
    rows, total = _cart_items(request)
    return render(request, "store/cart.html", {"cart_items": rows, "total": total})

@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id, active=True)
    cart_data = request.session.get("cart", {})
    key = str(product.id)
    cart_data[key] = int(cart_data.get(key, 0)) + 1
    request.session["cart"] = cart_data
    messages.success(request, f"{product.name} added to your cart.")
    return redirect(request.POST.get("next") or "cart")

@require_POST
def remove_from_cart(request, product_id):
    cart_data = request.session.get("cart", {})
    cart_data.pop(str(product_id), None)
    request.session["cart"] = cart_data
    return redirect("cart")

@login_required
def checkout(request):
    if request.method != "POST": return redirect("cart")
    rows, total = _cart_items(request)
    if not rows:
        messages.error(request, "Your cart is empty.")
        return redirect("cart")
    with transaction.atomic():
        order = Order.objects.create(user=request.user, total=total)
        for row in rows:
            OrderItem.objects.create(order=order, product=row["product"], quantity=row["quantity"], unit_price=row["product"].price)
    request.session["cart"] = {}
    messages.success(request, f"Order #{order.pk} has been placed. This demo does not process online payments.")
    return redirect("profile")

def rewards(request):
    return render(request, "store/rewards.html")

@login_required
def profile(request):
    orders = request.user.orders.prefetch_related("items__product").order_by("-created_at")
    return render(request, "store/profile.html", {"orders": orders})
