from django.urls import path
from . import views
urlpatterns = [
    path("", views.home, name="home"),
    path("products/", views.products, name="products"),
    path("search/", views.search, name="search"),
    path("login/", views.login_view, name="login"),
    path("register/", views.register, name="register"),
    path("logout/", views.logout_view, name="logout"),
    path("cart/", views.cart, name="cart"),
    path("cart/add/<int:product_id>/", views.add_to_cart, name="add_to_cart"),
    path("cart/remove/<int:product_id>/", views.remove_from_cart, name="remove_from_cart"),
    path("checkout/", views.checkout, name="checkout"),
    path("rewards/", views.rewards, name="rewards"),
    path("profile/", views.profile, name="profile"),
]
